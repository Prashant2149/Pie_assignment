function counter(num) {
    if (!num) {
        num = 0;
    }
    function getCurrentValue() {
        return num;
    }
    function getIncrementValue() {
        num++;
    }
    return [getCurrentValue, getIncrementValue];
}
var _a = counter(1), getA = _a[0], nextA = _a[1];
console.log(getA(), nextA());
console.log(getA(), nextA());