function counter(num:number): [() => number, () => void]{
    if(!num){
        num = 0;
    }
    function getCurrentValue (): number {
        return num;
    }
    function getIncrementValue () : void{
        num++;
    }
    return [getCurrentValue, getIncrementValue];
}
const [getA, nextA] = counter (1);
