async function getRickAndMortyEpisodesDetails () {
    try{
        const response = await fetch ('https://rickandmortyapi.com/api/episode');
    const data = await response.json();
    data.results.map(async (obj) => {
        for(const ind in obj.characters){
            const url = obj.characters[ind];
            let res = await fetch (url);
            res = await res.json();
            obj.characters[ind] = res;
        }
    });
    console.log(JSON.stringify(data,null,2));
    }
    catch(err){
        console.error('Error in getRickAndMortyEpisodesDetails function', err);
    }
}
getRickAndMortyEpisodesDetails();



